/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tugas6;

/**
 *
 * @author acer
 */
public class Main {
    public static void main(String[] args) {
        KeranjangBelanja keranjang = new KeranjangBelanja();

        keranjang.tambahProduk(new Buku("Harry Potter III", 100000));
        keranjang.tambahProduk(new Elektronik("Monitor", 150000));
        keranjang.tambahProduk(new Pakaian("Batik", 200000));

        keranjang.tampilkanRincian();
        System.out.println("Total setelah diskon: " + keranjang.hitungTotalHarga());
    }
}
