/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this licens
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package praktikum4;

/**
 *
 * @author acer
 */
public class Main {
    public static void main(String[] args) {
        // Objek Pekerja
        Pekerja pekerja1 = new Pekerja("Alex", 30, "Software Engineer", 10000000);

        // Tampilkan awal
        System.out.println("INFORMASI AWAL PEKERJA");
        System.out.println(pekerja1.toString());

        // Ubah nama dengan setter
        pekerja1.setNama("Alex Alexandria");

        // Tampilkan ulang
        System.out.println("\nINFORMASI SETELAH UBAH NAMA");
        System.out.println(pekerja1.toString());

        // Uji Akses Langsung Atribut
        System.out.println("\nUJI AKSES LANGSUNG");
        System.out.println("Usia (protected): " + pekerja1.usia);
        System.out.println("Pekerjaan (public): " + pekerja1.pekerjaan);
    }
}
