/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.praktikumpbo_4;

import praktikum4.Kendaraan;
import praktikum4.Mobil;

/**
 *
 * @author acer
 */
public class PraktikumPBO_4 {

    public static void main(String[] args) {
        Kendaraan kendaraan1 = new Kendaraan("Toyota Avanza", 160, "Bensin");
        
        System.out.println("=== Data Awal Kendaraan ===");
        System.out.println("Nama (getter): " + kendaraan1.getNama());
        kendaraan1.tampilkanInfoKendaraan();

        kendaraan1.setNama("Toyota Innova");

        kendaraan1.jenisMesin = "Diesel";

        System.out.println("\n=== Data Setelah Perubahan ===");
        System.out.println("Nama baru (getter): " + kendaraan1.getNama());
        kendaraan1.tampilkanInfoKendaraan();

        System.out.println("\n=== Data Mobil (Subclass dari Kendaraan) ===");
        Mobil mobil1 = new Mobil("Honda Jazz", 170, "Bensin", 5);
        mobil1.tampilkanInfoMobil();
        mobil1.tampilkanInfoKendaraan(); 
    }
}
