/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Praktikum5;

/**
 *
 * @author acer
 */
public class Mobil extends Kendaraan {
    int jumlahPintu;

    public void tampilkanInfoMobil() {
        System.out.println("Jumlah Pintu: " + jumlahPintu);
    }
    
    @Override
    public void tampilkanInfo() {
        super.tampilkanInfo();
        tampilkanInfoMobil();
    }
}