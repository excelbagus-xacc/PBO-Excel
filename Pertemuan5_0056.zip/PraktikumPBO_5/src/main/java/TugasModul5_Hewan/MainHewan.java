/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TugasModul5_Hewan;

/**
 *
 * @author acer
 */
public class MainHewan {
    public static void main(String[] args) {
        Kucing kucing = new Kucing("Miko");
        kucing.tampilkanInfo();

        System.out.println();

        Anjing anjing = new Anjing("Vasko");
        anjing.tampilkanInfo();
    }
}
