/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package TugasModul5_Hierarki;

/**
 *
 * @author acer
 */
public class MainHierarki {
    public static void main(String[] args) {
        Mobil mobil = new Mobil("Nissan Skyline", 250, 2);
        mobil.tampilkanInfo();

        System.out.println();

        SepedaMotor motor = new SepedaMotor("Vespa Matic", 90, "Matic 150cc");
        motor.tampilkanInfo();
    }
}
